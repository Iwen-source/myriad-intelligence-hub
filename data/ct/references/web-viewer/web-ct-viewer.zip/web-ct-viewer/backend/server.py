import io
import os
import tempfile
import traceback
import uuid
from dataclasses import dataclass
from typing import Dict, Tuple

import numpy as np
import SimpleITK as sitk
from flask import Flask, jsonify, request, send_file
from flask_cors import CORS

METAL_MASK_FILTER_NAME = "金属伪影掩码 Metal Artifact Mask"

app = Flask(__name__)
CORS(app)


@dataclass
class VolumeRecord:
    image: sitk.Image
    is_mask: bool = False
    source_name: str = ""
    series_id: str = ""
    file_count: int = 0


VOLUME_STORE: Dict[str, VolumeRecord] = {}


def read_dicom_series(dcm_folder: str) -> Tuple[sitk.Image, str, int]:
    reader = sitk.ImageSeriesReader()
    series_ids = reader.GetGDCMSeriesIDs(dcm_folder)
    if not series_ids:
        raise RuntimeError("当前文件夹中没有找到有效的 DICOM 序列。")

    best_series_id = None
    best_file_names = []
    for sid in series_ids:
        file_names = reader.GetGDCMSeriesFileNames(dcm_folder, sid)
        if len(file_names) > len(best_file_names):
            best_file_names = file_names
            best_series_id = sid

    reader.SetFileNames(best_file_names)
    image = reader.Execute()
    return image, best_series_id, len(best_file_names)


def serialize_image_to_nrrd_bytes(image: sitk.Image) -> bytes:
    with tempfile.NamedTemporaryFile(suffix=".nrrd", delete=False) as tmp:
        tmp_path = tmp.name
    try:
        sitk.WriteImage(image, tmp_path)
        with open(tmp_path, "rb") as f:
            return f.read()
    finally:
        if os.path.exists(tmp_path):
            os.remove(tmp_path)


def image_meta(image: sitk.Image, record: VolumeRecord):
    arr = sitk.GetArrayFromImage(image)
    size = image.GetSize()
    spacing = image.GetSpacing()
    return {
        "shape_zyx": list(arr.shape),
        "size_xyz": [int(size[0]), int(size[1]), int(size[2])],
        "spacing_xyz": [float(spacing[0]), float(spacing[1]), float(spacing[2])],
        "min": float(np.min(arr)),
        "max": float(np.max(arr)),
        "is_mask": bool(record.is_mask),
        "source_name": record.source_name,
        "series_id": record.series_id,
        "file_count": int(record.file_count),
    }


def run_filter(image: sitk.Image, filter_name: str, params: dict):
    image_float = sitk.Cast(image, sitk.sitkFloat32)

    if filter_name == "无滤波":
        return image_float, False

    if filter_name == "高斯滤波 Gaussian":
        sigma = float(params.get("spatial_sigma", 1.0))
        return sitk.SmoothingRecursiveGaussian(image_float, sigma), False

    if filter_name == "双边滤波 Bilateral":
        domain_sigma = float(params.get("spatial_sigma", 1.0))
        range_sigma = float(params.get("range_sigma", 50.0))
        bilateral = sitk.BilateralImageFilter()
        bilateral.SetDomainSigma(domain_sigma)
        bilateral.SetRangeSigma(range_sigma)
        return bilateral.Execute(image_float), False

    if filter_name == "中值滤波 Median":
        radius = int(params.get("median_radius", 1))
        median = sitk.MedianImageFilter()
        median.SetRadius([radius, radius, radius])
        return median.Execute(image_float), False

    if filter_name == "曲率流平滑 Curvature Flow":
        iterations = int(params.get("iterations", 5))
        time_step = float(params.get("time_step", 0.0625))
        result = sitk.CurvatureFlow(
            image_float, timeStep=time_step, numberOfIterations=iterations
        )
        return result, False

    if filter_name == "各向异性扩散 Anisotropic Diffusion":
        iterations = int(params.get("iterations", 5))
        time_step = float(params.get("time_step", 0.0625))
        conductance = float(params.get("conductance", 3.0))
        result = sitk.CurvatureAnisotropicDiffusion(
            image_float,
            timeStep=time_step,
            conductanceParameter=conductance,
            numberOfIterations=iterations,
        )
        return result, False

    if filter_name == METAL_MASK_FILTER_NAME:
        threshold_lower = float(params.get("metal_threshold_lower", 1000))
        threshold_upper = float(params.get("metal_threshold_upper", 4000))
        gradient_threshold = float(params.get("metal_gradient_threshold", 100))
        opening_radius = int(params.get("metal_opening_radius", 1))
        closing_radius = int(params.get("metal_closing_radius", 2))
        min_component_size = int(params.get("metal_min_component_size", 50))

        hu_mask = sitk.BinaryThreshold(
            image_float,
            lowerThreshold=threshold_lower,
            upperThreshold=threshold_upper,
            insideValue=1,
            outsideValue=0,
        )
        mask = sitk.Cast(hu_mask, sitk.sitkUInt8)

        gradient = sitk.GradientMagnitude(image_float)
        gradient_mask = sitk.BinaryThreshold(
            gradient,
            lowerThreshold=gradient_threshold,
            upperThreshold=1.0e12,
            insideValue=1,
            outsideValue=0,
        )
        gradient_mask = sitk.Cast(gradient_mask, sitk.sitkUInt8)

        if opening_radius > 0:
            opening = sitk.BinaryMorphologicalOpeningImageFilter()
            opening.SetKernelRadius([opening_radius] * mask.GetDimension())
            opening.SetForegroundValue(1)
            mask = opening.Execute(mask)

        if closing_radius > 0:
            closing = sitk.BinaryMorphologicalClosingImageFilter()
            closing.SetKernelRadius([closing_radius] * mask.GetDimension())
            closing.SetForegroundValue(1)
            mask = closing.Execute(mask)

        connected = sitk.ConnectedComponent(mask)
        if min_component_size > 0:
            relabeled = sitk.RelabelComponent(
                connected, minimumObjectSize=min_component_size
            )
        else:
            relabeled = connected

        edge_labels = sitk.Mask(relabeled, gradient_mask)
        label_stats = sitk.LabelShapeStatisticsImageFilter()
        label_stats.Execute(edge_labels)

        filtered_mask = sitk.Image(mask.GetSize(), sitk.sitkUInt8)
        filtered_mask.CopyInformation(mask)
        for label in label_stats.GetLabels():
            component_mask = sitk.BinaryThreshold(
                relabeled,
                lowerThreshold=label,
                upperThreshold=label,
                insideValue=1,
                outsideValue=0,
            )
            filtered_mask = sitk.Or(filtered_mask, sitk.Cast(component_mask, sitk.sitkUInt8))

        result = sitk.Cast(filtered_mask * 255, sitk.sitkUInt8)
        return result, True

    raise RuntimeError(f"未知滤波器：{filter_name}")


@app.route("/api/health", methods=["GET"])
def health():
    return jsonify({"ok": True})


@app.route("/api/load-nrrd", methods=["POST"])
def load_nrrd():
    if "file" not in request.files:
        return jsonify({"error": "缺少文件 file"}), 400

    file = request.files["file"]
    if not file.filename:
        return jsonify({"error": "文件名为空"}), 400

    suffix = os.path.splitext(file.filename)[1] or ".nrrd"
    with tempfile.NamedTemporaryFile(suffix=suffix, delete=False) as tmp:
        tmp_path = tmp.name
        file.save(tmp_path)

    try:
        image = sitk.ReadImage(tmp_path)
        volume_id = str(uuid.uuid4())
        record = VolumeRecord(image=image, source_name=file.filename)
        VOLUME_STORE[volume_id] = record
        return jsonify({"volume_id": volume_id, "meta": image_meta(image, record)})
    finally:
        if os.path.exists(tmp_path):
            os.remove(tmp_path)


@app.route("/api/load-dicom", methods=["POST"])
def load_dicom():
    files = request.files.getlist("files")
    if not files:
        return jsonify({"error": "请上传 DICOM 文件夹内容"}), 400

    with tempfile.TemporaryDirectory() as tmpdir:
        for index, f in enumerate(files):
            name = f.filename or f"dicom_{index}.dcm"
            safe_name = os.path.basename(name)
            out_path = os.path.join(tmpdir, f"{index:04d}_{safe_name}")
            f.save(out_path)

        image, series_id, file_count = read_dicom_series(tmpdir)
        volume_id = str(uuid.uuid4())
        record = VolumeRecord(
            image=image,
            source_name="DICOM Folder",
            series_id=series_id or "",
            file_count=file_count,
        )
        VOLUME_STORE[volume_id] = record
        return jsonify({"volume_id": volume_id, "meta": image_meta(image, record)})


@app.route("/api/volume/<volume_id>/nrrd", methods=["GET"])
def get_volume_nrrd(volume_id):
    record = VOLUME_STORE.get(volume_id)
    if not record:
        return jsonify({"error": "volume_id 不存在"}), 404

    payload = serialize_image_to_nrrd_bytes(record.image)
    return send_file(
        io.BytesIO(payload),
        mimetype="application/octet-stream",
        as_attachment=False,
        download_name=f"{volume_id}.nrrd",
    )


@app.route("/api/filter", methods=["POST"])
def apply_filter():
    data = request.get_json(force=True, silent=True) or {}
    source_volume_id = data.get("source_volume_id")
    filter_name = data.get("filter_name")
    params = data.get("params", {})

    if not source_volume_id or not filter_name:
        return jsonify({"error": "缺少 source_volume_id 或 filter_name"}), 400

    source_record = VOLUME_STORE.get(source_volume_id)
    if not source_record:
        return jsonify({"error": "source_volume_id 不存在"}), 404

    try:
        result_image, is_mask = run_filter(source_record.image, filter_name, params)
        result_id = str(uuid.uuid4())
        result_record = VolumeRecord(
            image=result_image,
            is_mask=is_mask,
            source_name=f"{source_record.source_name} | {filter_name}",
            series_id=source_record.series_id,
            file_count=source_record.file_count,
        )
        VOLUME_STORE[result_id] = result_record
        return jsonify(
            {
                "volume_id": result_id,
                "is_mask": is_mask,
                "message": f"滤波完成：{filter_name}",
                "meta": image_meta(result_image, result_record),
            }
        )
    except Exception as exc:
        return (
            jsonify({"error": str(exc), "traceback": traceback.format_exc()}),
            500,
        )


@app.route("/api/volume/<volume_id>/save", methods=["GET"])
def save_volume(volume_id):
    fmt = request.args.get("format", "nrrd")
    record = VOLUME_STORE.get(volume_id)
    if not record:
        return jsonify({"error": "volume_id 不存在"}), 404

    suffix = ".nrrd"
    if fmt in ("nii", "nii.gz"):
        suffix = ".nii.gz"

    with tempfile.NamedTemporaryFile(suffix=suffix, delete=False) as tmp:
        out_path = tmp.name

    try:
        sitk.WriteImage(record.image, out_path)
        with open(out_path, "rb") as f:
            payload = f.read()
    finally:
        if os.path.exists(out_path):
            os.remove(out_path)

    return send_file(
        io.BytesIO(payload),
        mimetype="application/octet-stream",
        as_attachment=True,
        download_name=f"filtered_volume{suffix}",
    )


if __name__ == "__main__":
    app.run(host="127.0.0.1", port=8000, debug=True)
