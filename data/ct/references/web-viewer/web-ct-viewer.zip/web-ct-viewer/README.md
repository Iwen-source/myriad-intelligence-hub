# Day3 Web CT Viewer (Vue + vtk.js + SimpleITK)

该版本将 `day2/dicom_viewer_gui.py` 的核心能力迁移到网页：

- DICOM 文件夹加载（自动选切片数最多的序列）
- NRRD / NIfTI 加载
- 2D 原图 / 滤波结果切片对比
- 窗宽窗位调节
- 3D 体渲染（vtk.js）
- 多滤波器处理（由 Python + SimpleITK 后端执行）
- 保存当前切片 PNG
- 保存体数据 NRRD / NIfTI

## 架构

- 前端：Vue 3 + Vite + vtk.js（端口 `5174`）
- 后端：Flask + SimpleITK（端口 `8000`）

## 启动步骤

### 1) 启动后端

```bash
cd backend
python -m pip install -r requirements.txt
python server.py
```

### 2) 启动前端

```bash
cd ..
npm install
npm run dev
```

然后访问：`http://localhost:5174`

## 滤波器列表

- 无滤波
- 高斯滤波 Gaussian
- 双边滤波 Bilateral
- 中值滤波 Median
- 曲率流平滑 Curvature Flow
- 各向异性扩散 Anisotropic Diffusion
- 金属伪影掩码 Metal Artifact Mask

## 说明

- 金属伪影掩码在 2D 视图会以红色叠加显示。
- 3D 传输函数已按 `day2` 逻辑迁移：普通体数据支持窗宽窗位，掩码采用固定红色高亮。

## 已知限制

- 浏览器上传大体积 DICOM 文件夹时，首次解析可能较慢。
- 当前网页版本未迁移桌面端多线程 UI 状态细节，但后端处理流程与算法保持一致。
